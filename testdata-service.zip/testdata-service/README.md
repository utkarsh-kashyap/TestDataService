# TestDataService

## Setup
1. Copy `.env.example` to `.env` and fill credentials (Oracle, MSSQL, LLM).
2. Install Python dependencies:
pip install -r requirements.txt

markdown


## Useful CLI flags (all available)
- `--only-step` accepts:
- `parse` — parse feature file and print examples
- `schema-fetch-oracle` — fetch Oracle schema and write `config/schema_oracle.txt`
- `schema-fetch-mssql` — fetch MSSQL schema and write `config/schema_mssql.txt`
- `llm-infer` — run a single example through the LLM inference and print refined SQL + predicate (no DB writes)
- `orchestrate` — full orchestrator (default)

- `--dry-run` — **important**: when set, the orchestrator will NOT execute DB queries; it will generate LLM outputs and write them to `OUTPUT_DIR` for review.

## Commands

1. Parse feature file (show scenarios & examples)
python -m src.app.main --feature-file samples/sample.feature --only-step parse

markdown


2. Fetch Oracle schema (writes `config/schema_oracle.txt`)
python -m src.app.main --feature-file samples/sample.feature --only-step schema-fetch-oracle

markdown


3. Fetch MSSQL schema (writes `config/schema_mssql.txt`)
python -m src.app.main --feature-file samples/sample.feature --only-step schema-fetch-mssql

sql


4. LLM inference (generate Oracle SQL + MSSQL predicate for first example — inspect)
python -m src.app.main --feature-file samples/sample.feature --only-step llm-infer

pgsql


5. Dry-run full flow (generate LLM outputs + write JSON, no DB queries)
python -m src.app.main --feature-file samples/sample.feature --dry-run

pgsql


6. Full end-to-end (execute DB queries — run only after you reviewed dry-run outputs)
python -m src.app.main --feature-file samples/sample.feature

markdown


Output: one JSON file per example in `OUTPUT_DIR` (default `./outputs`).

## Safety checklist (recommended)
- Always run `--dry-run` and inspect outputs in `outputs/` before full runs.
- Ensure `config/schema_oracle.txt` and `config/schema_mssql.txt` are accurate and current.
- Use low LLM temperature (0.0 default) for deterministic predicates.