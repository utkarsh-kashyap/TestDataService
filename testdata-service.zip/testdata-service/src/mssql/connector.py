# src/mssql/connector.py
import os
from dotenv import load_dotenv
load_dotenv()

try:
    import pyodbc
except Exception:
    pyodbc = None

class MSSQLConnector:
    def __init__(self):
        driver = os.getenv("MSSQL_DRIVER", "ODBC Driver 17 for SQL Server")
        server = os.getenv("MSSQL_SERVER")
        database = os.getenv("MSSQL_DATABASE")
        username = os.getenv("MSSQL_USERNAME")
        password = os.getenv("MSSQL_PASSWORD")
        trusted = os.getenv("MSSQL_TRUSTED_CONNECTION", "no").lower() in ("yes","true","1")
        if not (server and database):
            raise ValueError("MSSQL_SERVER and MSSQL_DATABASE must be set in .env")
        if trusted:
            self.conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
        else:
            if not (username and password):
                raise ValueError("MSSQL_USERNAME and MSSQL_PASSWORD must be set in .env")
            self.conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={username};PWD={password};"

    def get_connection(self):
        if pyodbc is None:
            raise RuntimeError("pyodbc library not installed")
        try:
            return pyodbc.connect(self.conn_str, autocommit=False)
        except Exception as e:
            raise RuntimeError(f"MSSQL connection failed: {e}")
