# src/mssql/executor.py
from typing import List
from ..app.config import Config
from .connector import MSSQLConnector
from ..app.query_validator import contains_forbidden, references_allowed_tables

def _chunk_list(lst: List[str], n: int):
    for i in range(0, len(lst), n):
        yield lst[i:i+n]

def validate_candidates(candidate_member_nos: List[str], predicate_template: str, top_n: int) -> List[str]:
    """
    Validate candidate member_no list using parameterized IN (...) and the MSSQL predicate.
    Returns validated member_no list up to top_n.
    """
    if not candidate_member_nos:
        return []
    if contains_forbidden(predicate_template):
        raise RuntimeError("Predicate contains forbidden tokens.")
    if not references_allowed_tables(predicate_template, [], Config.MSSQL_TABLES, owner_or_schema=Config.MSSQL_SCHEMA_NAME):
        raise RuntimeError("Predicate references disallowed tables.")
    main_table = f"{Config.MSSQL_SCHEMA_NAME}.{Config.MSSQL_TABLES[0]}" if Config.MSSQL_TABLES else None
    if not main_table:
        raise RuntimeError("No MSSQL main table configured for validation.")
    conn = MSSQLConnector().get_connection()
    cur = conn.cursor()
    validated_results = []
    try:
        for chunk in _chunk_list(candidate_member_nos, Config.MAX_SEND_PER_BATCH):
            placeholders = ", ".join(["?"] * len(chunk))
            validation_sql = f"""
            SELECT TOP ({top_n}) m.member_no
            FROM {main_table} m
            WHERE m.member_no IN ({placeholders})
              AND ({predicate_template})
            """
            cur.execute(validation_sql, tuple(chunk))
            rows = cur.fetchall()
            for r in rows:
                validated_results.append(r[0])
                if len(validated_results) >= top_n:
                    break
            if len(validated_results) >= top_n:
                break
        return validated_results
    finally:
        try:
            cur.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
