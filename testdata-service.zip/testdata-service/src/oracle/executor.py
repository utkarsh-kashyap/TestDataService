# src/oracle/executor.py
from typing import List, Dict, Tuple, Optional
from ..app.config import Config
from .connector import OracleConnector
from ..app.llm_adapter import call_llm_safe
from ..app.query_validator import contains_forbidden, references_allowed_tables
import re

BASE_CANDIDATE_TEMPLATE = """
SELECT {member_col} as MEMBER_NO, {account_col} as ACCOUNT_NO, {email_col} as EMAIL, {reg_col} as REGISTERED_FLAG,
       {dbcode_col} as DATABASE_CODE, {fundcode_col} as FUD_CODE
FROM {owner}.{table}
WHERE {dbcode_col} = :db_code
  AND {fundcode_col} IN ({fund_codes})
  AND {status_col} = 'ACTIVE'
  {extra_where}
"""

def build_base_template(owner: str, table: str, placeholders: Dict = None) -> str:
    placeholders = placeholders or {}
    member_col = placeholders.get("member_col", "USER_ID")
    account_col = placeholders.get("account_col", "ACCOUNT_NUMBER")
    email_col = placeholders.get("email_col", "EMAIL_ADDRESS")
    dbcode_col = placeholders.get("dbcode_col", "DATABASE_CODE")
    fundcode_col = placeholders.get("fundcode_col", "FUD_CODE")
    status_col = placeholders.get("status_col", "STATUS")
    reg_col = placeholders.get("reg_col", "IS_REGISTERED")
    extra_where = placeholders.get("extra_where", "")
    if extra_where:
        extra_where = "AND " + extra_where
    return BASE_CANDIDATE_TEMPLATE.format(
        owner=owner, table=table,
        member_col=member_col, account_col=account_col, email_col=email_col,
        reg_col=reg_col, dbcode_col=dbcode_col, fundcode_col=fundcode_col, status_col=status_col,
        fund_codes="{fund_codes}", extra_where=extra_where
    ).strip()

def extract_db_fund_from_rule(rule_block: Dict) -> Tuple[Optional[str], List[str]]:
    if not rule_block:
        return None, []
    db_codes = rule_block.get("db_codes") or []
    fund_codes = rule_block.get("fund_codes") or []
    db_code = None
    if isinstance(db_codes, list) and db_codes:
        db_code = db_codes[0]
    elif isinstance(db_codes, str) and db_codes:
        db_code = db_codes
    fcodes = []
    if isinstance(fund_codes, list):
        fcodes = fund_codes
    elif isinstance(fund_codes, str) and fund_codes:
        fcodes = [x.strip() for x in fund_codes.split(",") if x.strip()]
    return db_code, fcodes

def refine_template_with_llm(base_template: str, schema_text: str, rules_text: str, env_modifiers: Dict) -> str:
    prompt_parts = [
        "You are given a base Oracle SELECT template with placeholders.",
        "Using the SCHEMA and RULES below and ENV MODIFIERS, return a final parameterized SELECT statement.",
        "Do NOT include any DDL or dangerous tokens. Return ONLY the SQL between ```sql``` fences.",
        "\n---\nSCHEMA:\n", schema_text[:32000],
        "\n---\nRULES:\n", rules_text[:32000],
        "\n---\nBASE TEMPLATE:\n", base_template,
        "\n---\nENV MODIFIERS:\n", str(env_modifiers),
        "\n\nOutput SQL now."
    ]
    prompt = "\n".join(prompt_parts)
    out = call_llm_safe(prompt)
    m = re.search(r"```sql\s*(.*?)```", out, re.S | re.I)
    sql = m.group(1).strip() if m else out.strip()
    if contains_forbidden(sql):
        raise RuntimeError("LLM produced forbidden content in Oracle SQL.")
    if not references_allowed_tables(sql, Config.ORACLE_TABLES, Config.MSSQL_TABLES, owner_or_schema=Config.ORACLE_OWNER_NAME):
        raise RuntimeError("LLM referenced unauthorized tables in Oracle SQL.")
    return sql

def execute_refined_query(sql: str, bind_db_code: Optional[str], bind_fund_codes: List[str], limit: int) -> List[Dict]:
    fund_codes = bind_fund_codes or []
    if fund_codes:
        placeholders = ", ".join([f":f{i}" for i in range(len(fund_codes))])
    else:
        placeholders = "''"

    sql_exec = sql.replace("{fund_codes}", placeholders)

    if Config.ORACLE_SAMPLING == "random" and "ORDER BY" not in sql_exec.upper():
        sql_exec = sql_exec + "\nORDER BY DBMS_RANDOM.VALUE"

    if "ROWNUM" not in sql_exec.upper() and "FETCH FIRST" not in sql_exec.upper():
        sql_exec = f"SELECT * FROM (\n{sql_exec}\n) WHERE ROWNUM <= {limit}"

    conn = OracleConnector().get_connection()
    cur = conn.cursor()
    try:
        bind_params = []
        if ":DB_CODE" in sql_exec.upper() and bind_db_code is not None:
            bind_params.append(bind_db_code)
        for fc in fund_codes:
            bind_params.append(fc)
        if bind_params:
            cur.execute(sql_exec, bind_params)
        else:
            cur.execute(sql_exec)
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description] if cur.description else []
        results = []
        for r in rows:
            rec = {cols[i].upper(): r[i] for i in range(len(cols))}
            results.append(rec)
        return results
    finally:
        try:
            cur.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
