# src/app/orchestrator.py
from .feature_parser import parse_feature_file_text
from .rules_loader import load_rules, find_rules_by_label
from .llm_adapter import call_llm_safe
from ..oracle.schema_fetcher import fetch_schema_text as fetch_oracle_schema
from ..mssql.schema_fetcher import fetch_schema_text as fetch_mssql_schema
from ..oracle.executor import build_base_template, refine_template_with_llm, execute_refined_query, extract_db_fund_from_rule
from ..mssql.executor import validate_candidates
from .output_writer import write_result_file
from .config import Config
from .query_validator import contains_forbidden
import logging

logger = logging.getLogger(__name__)

def infer_templates_for_example(example_row: dict, rules_text: str, schema_oracle_text: str, schema_mssql_text: str):
    member_type = example_row.get("member_type") or example_row.get("Member Type")
    member_criteria = example_row.get("member_criteria") or example_row.get("member Criteria")
    rules = load_rules()
    matched = find_rules_by_label(member_type, rules)
    rule_block = matched[0] if matched else {}
    db_code, fund_codes = extract_db_fund_from_rule(rule_block)
    owner = Config.ORACLE_OWNER_NAME
    table = Config.ORACLE_TABLES[0]
    base_template = build_base_template(owner, table)
    env_modifiers = {}
    refined_oracle_sql = refine_template_with_llm(base_template, schema_oracle_text + "\n\n" + schema_mssql_text, str(rule_block), env_modifiers)
    prompt = [
        "Produce a MSSQL WHERE predicate (no semicolons) to validate candidate members based on the rule and schema.",
        "\n---\nRULE:\n", str(rule_block),
        "\n---\nMSSQL SCHEMA:\n", schema_mssql_text[:20000],
        "\n---\nCRITERIA:\n", str(member_criteria),
        "\n\nReturn only the predicate (plain text)."
    ]
    pred_prompt = "\n".join(prompt)
    mssql_predicate = call_llm_safe(pred_prompt)
    if mssql_predicate.startswith("```"):
        mssql_predicate = mssql_predicate.strip("```").strip()
    if contains_forbidden(mssql_predicate):
        raise RuntimeError("LLM returned forbidden tokens in MSSQL predicate.")
    return refined_oracle_sql, mssql_predicate, db_code, fund_codes, rule_block

def process_example(example_row: dict, scenario_name: str, example_index: int, rules_text: str, schema_oracle_text: str, schema_mssql_text: str, output_dir: str, dry_run: bool = False):
    total_needed = Config.TARGET_N
    results = []
    seen = set()
    oracle_sql, mssql_pred, db_code, fund_codes, rule_block = infer_templates_for_example(example_row, rules_text, schema_oracle_text, schema_mssql_text)
    if dry_run:
        out_obj = {
            "feature_scenario": scenario_name,
            "examples_row": example_row,
            "rule_block": rule_block,
            "oracle_sql": oracle_sql,
            "db_code": db_code,
            "fund_codes": fund_codes,
            "mssql_predicate": mssql_pred,
            "note": "dry_run=true; no DB execution performed"
        }
        path = write_result_file(scenario_name, example_index, example_row, out_obj, output_dir)
        logger.info(f"Dry-run output written to {path}")
        return path

    passes = ["registered", "active"] if Config.PREFER_REGISTERED else ["active"]
    pass_used = "active"
    for p in passes:
        logger.info(f"Starting pass: {p}")
        for batch_idx in range(1, Config.CANDIDATE_BATCHES + 1):
            try:
                batch_rows = execute_refined_query(oracle_sql, db_code, fund_codes, Config.CANDIDATE_BATCH_SIZE)
            except Exception as e:
                logger.error(f"Oracle batch fetch failed (batch {batch_idx}): {e}")
                batch_rows = []
            if not batch_rows:
                logger.info(f"Batch {batch_idx} returned no rows")
                continue
            registered_rows = []
            other_rows = []
            for r in batch_rows:
                reg_val = None
                for k in ("IS_REGISTERED","REGISTERED_FLAG","REGISTERED","ISREGISTERED"):
                    if k in r:
                        reg_val = r.get(k)
                        break
                if reg_val and str(reg_val).upper() in ("Y","YES","TRUE","1"):
                    registered_rows.append(r)
                else:
                    other_rows.append(r)
            candidate_source = registered_rows if (p == "registered") else (registered_rows + other_rows)
            if not candidate_source:
                continue
            remaining_needed = total_needed - len(results)
            if remaining_needed <= 0:
                break
            send_count = min(remaining_needed, len(candidate_source), Config.MAX_SEND_PER_BATCH)
            candidate_chunk = [str(rec.get("MEMBER_NO") or rec.get("USER_ID") or "") for rec in candidate_source[:send_count]]
            try:
                validated = validate_candidates(candidate_chunk, mssql_pred, remaining_needed)
            except Exception as e:
                logger.error(f"MSSQL validation failed for batch {batch_idx}: {e}")
                validated = []
            for mem in validated:
                if mem in seen:
                    continue
                match_row = next((r for r in candidate_source if str(r.get("MEMBER_NO") or r.get("USER_ID") or "") == str(mem)), None)
                if match_row:
                    out_item = {
                        "member_number": str(match_row.get("MEMBER_NO") or match_row.get("USER_ID") or ""),
                        "database_code": str(match_row.get("DATABASE_CODE") or match_row.get("DB_CODE") or ""),
                        "fund_code": str(match_row.get("FUD_CODE") or match_row.get("FUND_CODE") or ""),
                        "email": str(match_row.get("EMAIL") or match_row.get("EMAIL_ADDRESS") or ""),
                        "account_number": str(match_row.get("ACCOUNT_NO") or match_row.get("ACCOUNT_NUMBER") or "")
                    }
                    results.append(out_item)
                    seen.add(mem)
            logger.info(f"After batch {batch_idx}, validated total: {len(results)}")
            if len(results) >= total_needed:
                pass_used = p
                break
        if len(results) >= total_needed:
            break

    output_obj = {
        "feature_scenario": scenario_name,
        "examples_row": example_row,
        "rule_used": rule_block.get("name") if rule_block else "",
        "oracle_used_registered": (pass_used == "registered"),
        "final_matches_count": len(results),
        "results": results,
        "debug": {
            "oracle_sql": oracle_sql,
            "db_code": db_code,
            "fund_codes": fund_codes,
            "mssql_predicate": mssql_pred
        }
    }
    out_path = write_result_file(scenario_name, example_index, example_row, output_obj, output_dir)
    logger.info(f"Wrote output to {out_path}")
    return out_path

def run_orchestrator_for_feature(feature_text: str, rules_path: str, output_dir: str, dry_run: bool = False):
    Config.validate()
    schema_oracle = fetch_oracle_schema("config/schema_oracle.txt")
    schema_mssql = fetch_mssql_schema("config/schema_mssql.txt") if Config.MSSQL_TABLES else ""
    rules_text = ""
    if rules_path:
        try:
            rules_text = open(rules_path, "r", encoding="utf-8").read()
        except Exception:
            rules_text = ""
    scenarios = parse_feature_file_text(feature_text)
    output_paths = []
    for sc in scenarios:
        sname = sc.get("scenario_name") or "scenario"
        examples = sc.get("examples") or []
        for idx, ex in enumerate(examples, start=1):
            p = process_example(ex, sname, idx, rules_text, schema_oracle, schema_mssql, output_dir, dry_run=dry_run)
            output_paths.append(p)
    return output_paths
