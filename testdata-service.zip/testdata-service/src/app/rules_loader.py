# src/app/rules_loader.py
import os
import re
from typing import List, Dict

RULES_PATH_DEFAULT = os.getenv("RULES_PATH", "config/rules.txt")

def load_rules(rules_path: str = RULES_PATH_DEFAULT) -> List[Dict]:
    if not os.path.exists(rules_path):
        return []
    text = open(rules_path, "r", encoding="utf-8").read()
    blocks = [b.strip() for b in text.split("\n---\n") if b.strip()]
    out = []
    for b in blocks:
        d = {}
        for ln in b.splitlines():
            if ":" in ln:
                key, val = ln.split(":", 1)
                k = key.strip().lower()
                v = val.strip()
                if k in ("business_labels", "db_codes", "fund_codes", "tables"):
                    d.setdefault(k, []).extend([x.strip() for x in re.split(r",\s*", v) if x.strip()])
                else:
                    d[k] = v
        out.append(d)
    return out

def find_rules_by_label(label: str, rules: List[Dict]) -> List[Dict]:
    if not label:
        return []
    lbl = label.strip().lower()
    matches = []
    for r in rules:
        bls = r.get("business_labels") or []
        for b in bls:
            if b.strip().lower() == lbl:
                matches.append(r)
                break
    return matches
