# src/app/query_validator.py
import re
from typing import List
from .config import Config

def contains_forbidden(text: str) -> bool:
    if not text:
        return False
    t = text.upper()
    for tok in Config.FORBIDDEN_TOKENS:
        if tok.strip().upper() in t:
            return True
    return False

def references_allowed_tables(sql_text: str, oracle_tables: List[str], mssql_tables: List[str], owner_or_schema: str="") -> bool:
    """
    Heuristic check: ensure tables referenced by FROM/JOIN are in allowed lists.
    """
    if not sql_text:
        return True
    sql = sql_text.upper()
    allowed = set([t.strip().upper() for t in oracle_tables + mssql_tables])
    if owner_or_schema:
        allowed |= set([f"{owner_or_schema.upper()}.{t.strip().upper()}" for t in oracle_tables])
    found = set()
    for m in re.finditer(r"(FROM|JOIN|INTO)\s+([A-Z0-9_\.#]+)", sql):
        tbl = m.group(2).strip().upper()
        found.add(tbl)
    if not found:
        return True
    for f in found:
        if f.startswith("#"):
            continue
        if f in allowed:
            continue
        if "." in f and f in allowed:
            continue
        return False
    return True
