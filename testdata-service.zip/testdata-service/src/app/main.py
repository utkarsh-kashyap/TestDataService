# src/app/main.py
import argparse
import logging
import sys
from .config import Config
from .feature_parser import parse_feature_file_text
from . import orchestrator
from ..oracle.schema_fetcher import fetch_schema_text as fetch_oracle_schema
from ..mssql.schema_fetcher import fetch_schema_text as fetch_mssql_schema
import os

def setup_logging():
    os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
    logging.basicConfig(level=getattr(logging, Config.LOG_LEVEL, logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout)])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--feature-file", required=True, help="Path to .feature file")
    parser.add_argument("--rules-file", default="config/rules.txt", help="Path to rules.txt")
    parser.add_argument("--only-step", choices=["parse","schema-fetch-oracle","schema-fetch-mssql","llm-infer","orchestrate"], default="orchestrate")
    parser.add_argument("--output-dir", default=Config.OUTPUT_DIR)
    parser.add_argument("--dry-run", action="store_true", help="If set, do not execute DB queries; generate and save LLM outputs only")
    args = parser.parse_args()

    setup_logging()
    if args.only_step in ("schema-fetch-oracle","schema-fetch-mssql","orchestrate","llm-infer"):
        try:
            Config.validate()
        except Exception as e:
            logging.error(f"Config validation failed: {e}")
            raise

    feature_text = open(args.feature_file, "r", encoding="utf-8").read()
    if args.only_step == "parse":
        print(parse_feature_file_text(feature_text))
        return
    if args.only_step == "schema-fetch-oracle":
        txt = fetch_oracle_schema("config/schema_oracle.txt")
        print(txt[:2000])
        return
    if args.only_step == "schema-fetch-mssql":
        txt = fetch_mssql_schema("config/schema_mssql.txt")
        print(txt[:2000])
        return
    if args.only_step == "llm-infer":
        scenarios = parse_feature_file_text(feature_text)
        if not scenarios:
            print("No scenarios found")
            return
        sc = scenarios[0]
        ex = sc["examples"][0]
        schema_oracle = open("config/schema_oracle.txt", "r", encoding="utf-8").read() if (Config.ORACLE_TABLES and os.path.exists("config/schema_oracle.txt")) else ""
        schema_mssql = open("config/schema_mssql.txt", "r", encoding="utf-8").read() if (Config.MSSQL_TABLES and os.path.exists("config/schema_mssql.txt")) else ""
        rules_text = open(args.rules_file, "r", encoding="utf-8").read() if os.path.exists(args.rules_file) else ""
        oracle_sql, pred, db_code, fund_codes, _ = orchestrator.infer_templates_for_example(ex, rules_text, schema_oracle, schema_mssql)
        print("Oracle SQL (refined):\n", oracle_sql)
        print("\nDB_CODE:", db_code)
        print("\nFUND_CODES:", fund_codes)
        print("\nMSSQL predicate:\n", pred)
        return
    # default orchestrate
    out_paths = orchestrator.run_orchestrator_for_feature(feature_text, args.rules_file, args.output_dir, dry_run=args.dry_run)
    print("Done. Output files:")
    for p in out_paths:
        print(" -", p)

if __name__ == "__main__":
    main()
