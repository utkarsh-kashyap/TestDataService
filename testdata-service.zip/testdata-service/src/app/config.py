# src/app/config.py
import os
from dotenv import load_dotenv
load_dotenv()

def _split_csv(env_value):
    if not env_value:
        return []
    return [p.strip() for p in env_value.split(",") if p.strip()]

class Config:
    # Oracle
    ORACLE_DSN = os.getenv("ORACLE_DSN")
    ORACLE_USER = os.getenv("ORACLE_USER")
    ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD")
    ORACLE_OWNER_NAME = os.getenv("ORACLE_OWNER_NAME", "").strip()
    ORACLE_TABLES = _split_csv(os.getenv("ORACLE_TABLES", ""))
    ORACLE_MAX_TABLES = int(os.getenv("ORACLE_MAX_TABLES", "5"))

    # MSSQL / DWH
    MSSQL_DRIVER = os.getenv("MSSQL_DRIVER", "ODBC Driver 17 for SQL Server")
    MSSQL_SERVER = os.getenv("MSSQL_SERVER")
    MSSQL_DATABASE = os.getenv("MSSQL_DATABASE")
    MSSQL_USERNAME = os.getenv("MSSQL_USERNAME")
    MSSQL_PASSWORD = os.getenv("MSSQL_PASSWORD")
    MSSQL_SCHEMA_NAME = os.getenv("MSSQL_SCHEMA_NAME", "dbo")
    MSSQL_TABLES = _split_csv(os.getenv("MSSQL_TABLES", ""))
    MSSQL_MAX_TABLES = int(os.getenv("MSSQL_MAX_TABLES", "5"))

    # LLM
    LLM_API_URL = os.getenv("LLM_API_URL")
    LLM_API_KEY = os.getenv("LLM_API_KEY")
    LLM_MODEL = os.getenv("LLM_MODEL", "")
    LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "30"))
    LLM_RETRIES = int(os.getenv("LLM_RETRIES", "2"))

    # Behaviour / batching
    CANDIDATE_BATCHES = int(os.getenv("CANDIDATE_BATCHES", "10"))
    CANDIDATE_BATCH_SIZE = int(os.getenv("CANDIDATE_BATCH_SIZE", "200"))
    TARGET_N = int(os.getenv("TARGET_N", "20"))
    MAX_SEND_PER_BATCH = int(os.getenv("MAX_SEND_PER_BATCH", "20"))
    PREFER_REGISTERED = os.getenv("PREFER_REGISTERED", "true").lower() in ("true","1","yes")
    ORACLE_SAMPLING = os.getenv("ORACLE_SAMPLING_STRATEGY", "random")
    MAX_WORKERS = int(os.getenv("MAX_WORKERS", "12"))

    OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./outputs")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

    # simple forbidden tokens for LLM SQL output
    FORBIDDEN_TOKENS = [";", "DROP ", "DELETE ", "INSERT ", "UPDATE ", "ALTER ", "EXEC ", "XP_", "GRANT ", "TRUNCATE "]

    @classmethod
    def validate(cls):
        if not cls.ORACLE_DSN and not (os.getenv("ORACLE_HOST") and os.getenv("ORACLE_SERVICE")):
            raise ValueError("Oracle connection details missing (ORACLE_DSN or ORACLE_HOST+ORACLE_SERVICE).")
        if not (cls.ORACLE_USER and cls.ORACLE_PASSWORD):
            raise ValueError("ORACLE_USER and ORACLE_PASSWORD must be set.")
        if not cls.ORACLE_OWNER_NAME:
            raise ValueError("ORACLE_OWNER_NAME must be set.")
        if not cls.ORACLE_TABLES:
            raise ValueError("ORACLE_TABLES must list at least one table.")
        if len(cls.ORACLE_TABLES) > cls.ORACLE_MAX_TABLES:
            raise ValueError(f"Number of ORACLE_TABLES exceeds ORACLE_MAX_TABLES ({cls.ORACLE_MAX_TABLES}).")
        if cls.MSSQL_TABLES and len(cls.MSSQL_TABLES) > cls.MSSQL_MAX_TABLES:
            raise ValueError(f"Number of MSSQL_TABLES exceeds MSSQL_MAX_TABLES ({cls.MSSQL_MAX_TABLES}).")
