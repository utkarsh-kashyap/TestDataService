# src/mssql/schema_fetcher.py
from ..app.config import Config
from .connector import MSSQLConnector
import os

def fetch_schema_text(output_path: str = "config/schema_mssql.txt") -> str:
    try:
        conn = MSSQLConnector().get_connection()
        cur = conn.cursor()
    except Exception:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write("")
        return ""

    schema = Config.MSSQL_SCHEMA_NAME.strip()
    lines = []
    for t in Config.MSSQL_TABLES:
        table = t.strip()
        full = f"{schema}.{table}" if schema else table
        lines.append(f"TABLE: {full}")
        lines.append("COLUMNS:")
        try:
            q = """
            SELECT COLUMN_NAME, DATA_TYPE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
            ORDER BY ORDINAL_POSITION
            """
            cur.execute(q, (schema, table))
            rows = cur.fetchall()
            for col_name, data_type in rows:
                lines.append(f" - {col_name} ({data_type})")
        except Exception:
            try:
                cur.execute(f"SELECT TOP (1) * FROM {full}")
                cols = [d[0] for d in cur.description]
                for c in cols:
                    lines.append(f" - {c} (UNKNOWN)")
            except Exception:
                lines.append(" - <could not fetch columns>")
        try:
            cur.execute(f"SELECT TOP (2) * FROM {full}")
            rows = cur.fetchall()
            if rows:
                colnames = [d[0] for d in cur.description]
                lines.append("SAMPLE ROWS:")
                for r in rows:
                    sample = ", ".join([f"{cn}={str(rv)[:200]}" for cn, rv in zip(colnames, r)])
                    lines.append(f" {sample}")
        except Exception:
            lines.append("SAMPLE ROWS: <could not fetch>")
        lines.append("")
    try:
        cur.close()
        conn.close()
    except Exception:
        pass
    text = "\n".join(lines)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return text
