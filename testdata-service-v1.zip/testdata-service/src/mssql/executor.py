# src/mssql/executor.py
from typing import List, Dict, Any
from ..app.config import Config
from .connector import MSSQLConnector
from ..app.query_validator import contains_forbidden, references_allowed_tables, extract_columns_from_sql
import re

def _chunk_list(lst: List[str], n: int):
    for i in range(0, len(lst), n):
        yield lst[i:i+n]

def execute_full_sql_with_candidates(sql_template: str, candidate_member_nos: List[str], top_n: int) -> List[Dict[str, Any]]:
    """
    Execute a full MSSQL SELECT template that must include {candidate_placeholders}.
    Candidate_member_nos is a list of strings.
    Returns rows as list of dicts (uppercase column keys).
    """
    if not candidate_member_nos:
        return []
    if contains_forbidden(sql_template):
        raise RuntimeError("SQL template contains forbidden tokens")
    if not references_allowed_tables(sql_template, [], Config.MSSQL_TABLES, owner_or_schema=Config.MSSQL_SCHEMA_NAME):
        raise RuntimeError("SQL references disallowed tables")
    if "{candidate_placeholders}" not in sql_template:
        raise RuntimeError("SQL template must include {candidate_placeholders}")

    conn = MSSQLConnector().get_connection()
    cur = conn.cursor()
    try:
        validated_results = []
        for chunk in _chunk_list(candidate_member_nos, Config.MAX_SEND_PER_BATCH):
            placeholders = ", ".join(["?"] * len(chunk))
            sql_exec = sql_template.replace("{candidate_placeholders}", placeholders)
            if re.search(r"\bTOP\s*\(", sql_exec, re.I) is None and "LIMIT" not in sql_exec.upper():
                sql_exec = sql_exec.replace("SELECT", f"SELECT TOP ({top_n})", 1)
            cur.execute(sql_exec, tuple(chunk))
            rows = cur.fetchall()
            if not rows:
                continue
            cols = [d[0] for d in cur.description]
            for r in rows:
                rec = {cols[i].upper(): r[i] for i in range(len(cols))}
                validated_results.append(rec)
                if len(validated_results) >= top_n:
                    break
            if len(validated_results) >= top_n:
                break
        return validated_results
    finally:
        try:
            cur.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
