# src/app/feature_parser.py
from typing import List, Dict

def parse_feature_file_text(feature_text: str) -> List[Dict]:
    """
    Very small parser: extracts Scenario Outline and Examples rows.
    Returns scenarios: [{"scenario_name": str, "examples": [ {col: val}, ... ]}, ...]
    """
    scenarios = []
    lines = feature_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.lower().startswith("scenario outline:"):
            scenario_name = line.split(":",1)[1].strip()
            # find Examples:
            j = i + 1
            while j < len(lines) and "examples" not in lines[j].lower():
                j += 1
            if j >= len(lines):
                i = j
                continue
            # find header row
            k = j + 1
            while k < len(lines) and lines[k].strip() == "":
                k += 1
            if k >= len(lines) or "|" not in lines[k]:
                i = k
                continue
            header_line = lines[k].strip()
            headers = [h.strip() for h in header_line.strip("|").split("|")]
            k += 1
            examples = []
            while k < len(lines) and "|" in lines[k]:
                row = [c.strip() for c in lines[k].strip().strip("|").split("|")]
                if len(row) == len(headers):
                    examples.append(dict(zip(headers, row)))
                k += 1
            scenarios.append({"scenario_name": scenario_name, "examples": examples})
            i = k
        else:
            i += 1
    return scenarios
