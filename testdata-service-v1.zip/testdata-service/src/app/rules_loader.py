# src/app/rules_loader.py
import os
import re
from typing import List, Dict

RULES_PATH_DEFAULT = os.getenv("RULES_PATH", "config/rules.txt")

def _split_vals(v: str):
    return [x.strip() for x in re.split(r",\s*", v) if x.strip()]

def load_rules(rules_path: str = RULES_PATH_DEFAULT) -> List[Dict]:
    """
    Load rules separated by --- blocks.
    Accepts keys (case-insensitive) such as:
      - NAME, DESCRIPTION, BUSINESS_LABELS, DB_CODES, FUND_CODES
      - OUTPUT_COLUMNS (comma-separated), ACTIVE_EXAMPLE_QUERY, REGISTERED_EXAMPLE_QUERY, EXAMPLE_HINTS
      - PREDICATE_TEMPLATE
    """
    if not os.path.exists(rules_path):
        return []
    text = open(rules_path, "r", encoding="utf-8").read()
    blocks = [b.strip() for b in text.split("\n---\n") if b.strip()]
    out = []
    for b in blocks:
        d = {}
        lines = b.splitlines()
        current_key = None
        current_val_lines = []
        for ln in lines:
            if ":" in ln and not ln.strip().startswith("#"):
                # commit previous
                if current_key:
                    value = "\n".join(current_val_lines).strip()
                    d[current_key] = value
                    current_val_lines = []
                key, val = ln.split(":", 1)
                current_key = key.strip().upper()
                val = val.strip()
                if val != "":
                    current_val_lines.append(val)
                else:
                    current_val_lines = []
            else:
                if current_key:
                    current_val_lines.append(ln.rstrip())
        if current_key:
            d[current_key] = "\n".join(current_val_lines).strip()
        # normalize lists
        for k in ("BUSINESS_LABELS","DB_CODES","FUND_CODES","OUTPUT_COLUMNS"):
            if k in d:
                d[k] = _split_vals(d[k])
        out.append(d)
    return out

def find_rules_by_label(label: str, rules: List[Dict]) -> List[Dict]:
    if not label:
        return []
    lbl = label.strip().lower()
    matches = []
    for r in rules:
        bls = r.get("BUSINESS_LABELS") or []
        for b in bls:
            if b.strip().lower() == lbl:
                matches.append(r)
                break
    return matches
