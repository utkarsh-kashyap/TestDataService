# src/app/llm_adapter.py
import time
from typing import Optional
from .config import Config

try:
    from src.llm_client import call_llm as _call_llm  # type: ignore
except Exception:
    _call_llm = None

if _call_llm is None:
    def call_llm_safe(prompt: str, timeout: Optional[int] = None, temperature: float = 0.0, max_tokens: int = None) -> str:
        raise RuntimeError("No LLM client implementation found at src/llm_client.py. Place your working client there exposing call_llm(prompt).")
else:
    def call_llm_safe(prompt: str, timeout: Optional[int] = None, temperature: float = 0.0, max_tokens: int = None) -> str:
        retries = max(1, Config.LLM_RETRIES)
        for attempt in range(1, retries + 1):
            try:
                if max_tokens is None:
                    return _call_llm(prompt, temperature=temperature)
                else:
                    return _call_llm(prompt, temperature=temperature, max_tokens=max_tokens)
            except Exception:
                if attempt == retries:
                    raise
                time.sleep(1.0 * attempt)
