# src/app/orchestrator.py
import json
import os
import re
import logging
from .feature_parser import parse_feature_file_text
from .rules_loader import load_rules, find_rules_by_label
from .llm_adapter import call_llm_safe
from ..oracle.schema_fetcher import fetch_schema_text as fetch_oracle_schema
from ..mssql.schema_fetcher import fetch_schema_text as fetch_mssql_schema
from ..oracle.executor import build_base_template, refine_template_with_llm, execute_refined_query, extract_db_fund_from_rule
from ..mssql.executor import execute_full_sql_with_candidates
from .output_writer import write_result_file
from .config import Config
from .query_validator import contains_forbidden, references_allowed_tables, extract_columns_from_sql
from typing import Tuple, List, Dict, Any

logger = logging.getLogger(__name__)

LEARNED_TEMPLATES_PATH = "config/learned_templates.json"

def _load_learned_templates() -> Dict[str, str]:
    if os.path.exists(LEARNED_TEMPLATES_PATH):
        try:
            return json.load(open(LEARNED_TEMPLATES_PATH, "r", encoding="utf-8"))
        except Exception:
            return {}
    return {}

def _save_learned_template(key: str, sql: str):
    data = _load_learned_templates()
    data[key] = sql
    os.makedirs(os.path.dirname(LEARNED_TEMPLATES_PATH) or ".", exist_ok=True)
    with open(LEARNED_TEMPLATES_PATH, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)

def _clean_sql_from_codefences(text: str) -> str:
    m = re.search(r"```sql\s*(.*?)```", text, re.S | re.I)
    if m:
        return m.group(1).strip()
    return text.strip()

def _build_template_key(member_type: str, criterion: str, dwh_table: str) -> str:
    return f"{member_type}||{criterion}||{dwh_table}"

def infer_templates_for_example(
    example_row: dict, rules_text: str, schema_oracle_text: str, schema_mssql_text: str
) -> Tuple[str, str, str, List[str], Dict[str, Any], List[str]]:
    member_type = example_row.get("member_type") or example_row.get("Member Type")
    member_criteria = example_row.get("member_criteria") or example_row.get("member Criteria")

    rules = load_rules()
    matched = find_rules_by_label(member_type, rules)
    rule_block = matched[0] if matched else {}

    crit_rule = None
    for r in rules:
        bls = r.get("BUSINESS_LABELS") or []
        if any(b.strip().lower() == (member_criteria or "").strip().lower() for b in bls):
            crit_rule = r
            break

    db_code, fund_codes = extract_db_fund_from_rule(rule_block)
    owner = Config.ORACLE_OWNER_NAME
    table = Config.ORACLE_TABLES[0]
    base_template = build_base_template(owner, table)
    refined_oracle_sql = refine_template_with_llm(base_template, schema_oracle_text + "\n\n" + schema_mssql_text, rules_text, {})

    dwh_table = (crit_rule.get("DWH_TABLE") or "").strip() if crit_rule else ""
    required_output_cols = crit_rule.get("OUTPUT_COLUMNS") if crit_rule else []

    # learned templates used as additional context (if present)
    learned_templates = _load_learned_templates()
    learned_block = ""
    lt_key = _build_template_key(member_type or "", member_criteria or "", dwh_table or "")
    if learned_templates:
        # include all learned templates (or only matching key) — include matching key first if present
        if lt_key in learned_templates:
            learned_block += f"\n-- Learned template for key {lt_key}:\n{learned_templates[lt_key]}\n"
        # include 2 other learned templates as examples (if any) to help LLM generalize
        for k, v in list(learned_templates.items())[:3]:
            if k != lt_key:
                learned_block += f"\n-- Other learned template {k}:\n{v}\n"

    # Build prompt including rules_text, schema, learned templates and a strict requirement for {candidate_placeholders}
    examples_in_rule = ""
    if crit_rule:
        for k in ("EXAMPLE_HINTS", "ACTIVE_EXAMPLE_QUERY", "REGISTERED_EXAMPLE_QUERY"):
            if k in crit_rule and crit_rule[k]:
                examples_in_rule += f"\n-- {k}:\n{crit_rule[k]}\n"

    prompt = f"""
You are a SQL-generation assistant. Produce exactly ONE MSSQL SELECT statement (no explanation).
Context:
1) FULL RULES:
{rules_text[:200000]}
2) MSSQL SCHEMA:
{schema_mssql_text[:200000]}
3) Learned templates (may be empty):
{learned_block}
4) Business request:
 - Member type: {member_type}
 - Criteria: {member_criteria}
 - Preferred DWH table: {dwh_table}
 - Requested DWH output columns: {required_output_cols}
5) Rule-level examples/hints:
{examples_in_rule}

Output requirements (MUST follow):
 - Return exactly ONE SELECT statement only (inside ```sql``` fences or plain SQL).
 - The SELECT MUST include the token {{candidate_placeholders}} (example: IN ({{candidate_placeholders}})).
 - Use only tables/columns from the MSSQL schema above. Do NOT invent columns.
 - Do NOT use DDL or semicolons.
 - Do NOT coerce alphanumeric fund codes to integers; use types/formats shown in schema.
 - Keep it simple and include ORDER BY if useful.
 - If a learned template exists for this key, you may reuse it or improve it.

Return the SELECT now.
"""
    llm_out = call_llm_safe(prompt, temperature=0.0, max_tokens=1600)
    sql_out = _clean_sql_from_codefences(llm_out).strip()

    if contains_forbidden(sql_out):
        raise RuntimeError("LLM-generated MSSQL SQL contains forbidden tokens.")
    if "{candidate_placeholders}" not in sql_out:
        retry_prompt = f"""
Your previous SQL did not include the required token {{candidate_placeholders}}.
Please regenerate one MSSQL SELECT that includes the token exactly as '{{candidate_placeholders}}' and uses only allowed columns from schema.
Return only the SQL.
"""
        llm_out2 = call_llm_safe(retry_prompt, temperature=0.0, max_tokens=1200)
        sql_out2 = _clean_sql_from_codefences(llm_out2).strip()
        if "{candidate_placeholders}" not in sql_out2:
            raise RuntimeError("LLM failed to include {candidate_placeholders} after retry.")
        sql_out = sql_out2

    if not references_allowed_tables(sql_out, [], Config.MSSQL_TABLES, owner_or_schema=Config.MSSQL_SCHEMA_NAME):
        raise RuntimeError("LLM SQL referenced disallowed tables.")

    used_cols = extract_columns_from_sql(sql_out)
    allowed_cols = set()
    for ln in schema_mssql_text.splitlines():
        ln = ln.strip()
        if ln.startswith("- "):
            parts = ln[2:].split()
            if parts:
                allowed_cols.add(parts[0].upper())
    unknown = [c for c in used_cols if c and c not in allowed_cols]
    if unknown:
        allowed_list = ", ".join(sorted(list(allowed_cols)))[:4000]
        retry_prompt2 = f"""
Your previous SQL used columns not in the MSSQL schema: {unknown}
Allowed columns: {allowed_list}
Regenerate exactly ONE MSSQL SELECT including {{candidate_placeholders}} using only allowed columns.
Return only the SQL.
"""
        llm_out3 = call_llm_safe(retry_prompt2, temperature=0.0, max_tokens=1200)
        sql_out3 = _clean_sql_from_codefences(llm_out3).strip()
        if contains_forbidden(sql_out3):
            raise RuntimeError("LLM retry produced forbidden tokens.")
        if not references_allowed_tables(sql_out3, [], Config.MSSQL_TABLES, owner_or_schema=Config.MSSQL_SCHEMA_NAME):
            raise RuntimeError("LLM retry referenced disallowed tables.")
        used_cols2 = extract_columns_from_sql(sql_out3)
        unknown2 = [c for c in used_cols2 if c and c not in allowed_cols]
        if unknown2:
            raise RuntimeError(f"LLM used unknown columns after retry: {unknown2}")
        sql_out = sql_out3

    return refined_oracle_sql, sql_out, db_code, fund_codes, rule_block, required_output_cols

def process_example(example_row: dict, scenario_name: str, example_index: int, rules_path: str, schema_oracle_text: str, schema_mssql_text: str, output_dir: str, dry_run: bool = False):
    total_needed = Config.TARGET_N
    results = []
    seen = set()
    try:
        rules_text = open(rules_path, "r", encoding="utf-8").read()
    except Exception:
        rules_text = ""

    oracle_sql, mssql_template, db_code, fund_codes, rule_block, required_output_cols = infer_templates_for_example(
        example_row, rules_text, schema_oracle_text, schema_mssql_text
    )

    if dry_run:
        out_obj = {
            "feature_scenario": scenario_name,
            "examples_row": example_row,
            "rule_block": rule_block,
            "oracle_sql": oracle_sql,
            "db_code": db_code,
            "fund_codes": fund_codes,
            "mssql_sql_template": mssql_template,
            "requested_output_columns": required_output_cols,
            "note": "dry_run=true; no DB execution performed"
        }
        path = write_result_file(scenario_name, example_index, example_row, out_obj, output_dir)
        logger.info("Dry-run output written to %s", path)
        return path

    if "{candidate_placeholders}" not in mssql_template:
        raise RuntimeError("MSSQL template does not include {candidate_placeholders} token.")

    passes = ["registered", "active"] if Config.PREFER_REGISTERED else ["active"]
    pass_used = "active"

    # determine dwh table for learned key
    member_type = example_row.get("member_type") or example_row.get("Member Type")
    member_criteria = example_row.get("member_criteria") or example_row.get("member Criteria")
    dwh_table = ""
    crit_rule = None
    rules = load_rules()
    for r in rules:
        bls = r.get("BUSINESS_LABELS") or []
        if any(b.strip().lower() == (member_criteria or "").strip().lower() for b in bls):
            crit_rule = r
            break
    if crit_rule:
        dwh_table = crit_rule.get("DWH_TABLE") or ""
    learned_key = _build_template_key(member_type or "", member_criteria or "", dwh_table or "")

    for p in passes:
        logger.info("Starting pass: %s", p)
        for batch_idx in range(1, Config.CANDIDATE_BATCHES + 1):
            try:
                batch_rows = execute_refined_query(oracle_sql, db_code, fund_codes, Config.CANDIDATE_BATCH_SIZE)
            except Exception as e:
                logger.error("Oracle batch fetch failed (batch %s): %s", batch_idx, e)
                batch_rows = []
            if not batch_rows:
                logger.info("Batch %s returned no rows", batch_idx)
                continue

            registered_rows = []
            other_rows = []
            for r in batch_rows:
                reg_val = None
                for k in ("IS_REGISTERED","REGISTERED_FLAG","REGISTERED","ISREGISTERED"):
                    if k in r:
                        reg_val = r.get(k)
                        break
                if reg_val and str(reg_val).upper() in ("Y","YES","TRUE","1"):
                    registered_rows.append(r)
                else:
                    other_rows.append(r)

            candidate_source = registered_rows if (p == "registered") else (registered_rows + other_rows)
            if not candidate_source:
                continue

            remaining_needed = total_needed - len(results)
            if remaining_needed <= 0:
                break

            send_count = min(len(candidate_source), Config.MAX_SEND_PER_BATCH)
            candidate_chunk = [str(rec.get("MEMBER_NO") or rec.get("USER_ID") or "") for rec in candidate_source[:send_count] if (rec.get("MEMBER_NO") or rec.get("USER_ID"))]
            if not candidate_chunk:
                continue

            try:
                mssql_rows = execute_full_sql_with_candidates(mssql_template, candidate_chunk, remaining_needed)
            except Exception as e:
                logger.error("MSSQL execution failed for batch %s: %s", batch_idx, e)
                mssql_rows = []

            for mr in mssql_rows:
                member_no = None
                for variant in ("MEMBERNUMBER","MEMBER_NUMBER","MEMBER_NO","MEMBERNO"):
                    if variant in mr and mr[variant] is not None:
                        member_no = str(mr[variant])
                        break
                if not member_no:
                    continue
                if member_no in seen:
                    continue

                match_row = None
                for r in candidate_source:
                    cand = str(r.get("MEMBER_NO") or r.get("USER_ID") or "")
                    if cand == member_no:
                        match_row = r
                        break

                out_item = {
                    "member_number": member_no,
                    "database_code": str(match_row.get("DATABASE_CODE") if match_row else ""),
                    "fund_code": str(match_row.get("FUD_CODE") or match_row.get("FUND_CODE") if match_row else ""),
                    "account_number": str(match_row.get("ACCOUNT_NO") or match_row.get("ACCOUNT_NUMBER") or ""),
                    "email": str(match_row.get("EMAIL") or match_row.get("EMAIL_ADDRESS") or "")
                }

                for col in (required_output_cols or []):
                    ckey = col.strip().upper()
                    out_item[ckey] = mr.get(ckey)

                results.append(out_item)
                seen.add(member_no)
                if len(results) >= total_needed:
                    pass_used = p
                    break

            logger.info("After batch %s, validated total: %s", batch_idx, len(results))
            if len(results) >= total_needed:
                break
        if len(results) >= total_needed:
            break

    if results:
        try:
            _save_learned_template(learned_key, mssql_template)
            logger.info("Saved learned template for key=%s", learned_key)
        except Exception as e:
            logger.warning("Failed to save learned template: %s", e)

    output_obj = {
        "feature_scenario": scenario_name,
        "examples_row": example_row,
        "rule_used": rule_block.get("NAME") if rule_block else "",
        "oracle_used_registered": (pass_used == "registered"),
        "final_matches_count": len(results),
        "results": results,
        "debug": {
            "oracle_sql": oracle_sql,
            "db_code": db_code,
            "fund_codes": fund_codes,
            "mssql_sql_template": mssql_template,
            "requested_output_columns": required_output_cols
        }
    }
    out_path = write_result_file(scenario_name, example_index, example_row, output_obj, output_dir)
    logger.info("Wrote output to %s", out_path)
    return out_path

def run_orchestrator_for_feature(feature_text: str, rules_path: str, output_dir: str, dry_run: bool = False):
    Config.validate()
    schema_oracle = fetch_oracle_schema("config/schema_oracle.txt")
    schema_mssql = fetch_mssql_schema("config/schema_mssql.txt") if Config.MSSQL_TABLES else ""
    rules_text = ""
    if rules_path:
        try:
            rules_text = open(rules_path, "r", encoding="utf-8").read()
        except Exception:
            rules_text = ""
    scenarios = parse_feature_file_text(feature_text)
    output_paths = []
    for sc in scenarios:
        sname = sc.get("scenario_name") or "scenario"
        examples = sc.get("examples") or []
        for idx, ex in enumerate(examples, start=1):
            p = process_example(ex, sname, idx, rules_path, schema_oracle, schema_mssql, output_dir, dry_run=dry_run)
            output_paths.append(p)
    return output_paths
