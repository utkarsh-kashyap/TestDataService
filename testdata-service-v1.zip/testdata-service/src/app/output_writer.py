# src/app/output_writer.py
import os
import json
from datetime import datetime

def write_result_file(scenario_name: str, example_index: int, examples_row: dict, result_obj: dict, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    safe_sname = "".join([c if c.isalnum() or c in (" ","_","-") else "_" for c in scenario_name])[:60].strip().replace(" ", "_")
    filename = f"{safe_sname}_ex{example_index}_{ts}.json"
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(result_obj, fh, indent=2, default=str)
    return path
