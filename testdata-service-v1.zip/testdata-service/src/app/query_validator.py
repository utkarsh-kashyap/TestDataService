# src/app/query_validator.py
import re
from typing import List, Set
from .config import Config

def contains_forbidden(text: str) -> bool:
    if not text:
        return False
    t = text.upper()
    for tok in Config.FORBIDDEN_TOKENS:
        if tok.strip().upper() in t:
            return True
    return False

def references_allowed_tables(sql_text: str, oracle_tables: List[str], mssql_tables: List[str], owner_or_schema: str="") -> bool:
    """
    Heuristic to ensure FROM/JOIN references only allowed tables.
    """
    if not sql_text:
        return True
    sql = sql_text.upper()
    allowed = set([t.strip().upper() for t in oracle_tables + mssql_tables])
    if owner_or_schema:
        allowed |= set([f"{owner_or_schema.upper()}.{t.strip().upper()}" for t in oracle_tables])
    for m in re.finditer(r"(FROM|JOIN|INTO)\s+([A-Z0-9_\.]+)", sql):
        tbl = m.group(2).strip().upper()
        if tbl.startswith("#"):
            continue
        if tbl not in allowed and not any(tbl.endswith("."+at) for at in allowed):
            return False
    return True

def extract_columns_from_sql(sql_text: str) -> Set[str]:
    """
    Heuristic to extract referenced column names from SQL (table.column patterns and bare names).
    Returns uppercase column names (no table prefix).
    """
    if not sql_text:
        return set()
    cols = set()
    for m in re.finditer(r"[A-Z0-9_]+\.[A-Z0-9_]+", sql_text, re.I):
        part = m.group(0)
        if "." in part:
            cols.add(part.split(".")[1].upper())
    m = re.search(r"SELECT(.*?)FROM", sql_text, re.S | re.I)
    if m:
        select_part = m.group(1)
        candidates = re.findall(r"\b([A-Z_][A-Z0-9_]+)\b", select_part, re.I)
        for c in candidates:
            cols.add(c.upper())
    m = re.search(r"WHERE(.*)", sql_text, re.S | re.I)
    if m:
        where_part = m.group(1)
        candidates = re.findall(r"\b([A-Z_][A-Z0-9_]+)\b", where_part, re.I)
        for c in candidates:
            cols.add(c.upper())
    return cols
