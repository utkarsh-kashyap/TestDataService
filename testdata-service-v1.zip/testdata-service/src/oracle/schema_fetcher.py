# src/oracle/schema_fetcher.py
import os
from ..app.config import Config
from .connector import OracleConnector

def fetch_schema_text(output_path: str = "config/schema_oracle.txt") -> str:
    conn = None
    try:
        conn = OracleConnector().get_connection()
        cur = conn.cursor()
    except Exception:
        # create empty schema file
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write("")
        return ""

    owner = Config.ORACLE_OWNER_NAME.strip().upper()
    lines = []
    for t in Config.ORACLE_TABLES:
        tbl = t.strip().upper()
        full = f"{owner}.{tbl}" if owner else tbl
        lines.append(f"TABLE: {full}")
        lines.append("COLUMNS:")
        try:
            q = """
            SELECT COLUMN_NAME, DATA_TYPE
            FROM ALL_TAB_COLUMNS
            WHERE OWNER = :owner AND TABLE_NAME = :table
            ORDER BY COLUMN_ID
            """
            cur.execute(q, [owner, tbl])
            cols = cur.fetchall()
            for cname, dtype in cols:
                lines.append(f" - {cname} ({dtype})")
        except Exception:
            try:
                cur.execute(f"SELECT * FROM {full} WHERE ROWNUM = 1")
                cols = [d[0] for d in cur.description]
                for cname in cols:
                    lines.append(f" - {cname} (UNKNOWN)")
            except Exception:
                lines.append(" - <could not fetch columns>")
        try:
            cur.execute(f"SELECT * FROM {full} WHERE ROWNUM <= 2")
            rows = cur.fetchall()
            if rows:
                lines.append("SAMPLE ROWS:")
                colnames = [d[0] for d in cur.description]
                for r in rows:
                    sample = ", ".join([f"{cn}={str(rv)[:200]}" for cn, rv in zip(colnames, r)])
                    lines.append(f" {sample}")
        except Exception:
            lines.append("SAMPLE ROWS: <could not fetch>")
        lines.append("")
    try:
        cur.close()
        conn.close()
    except Exception:
        pass
    text = "\n".join(lines)
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return text
